﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PR12
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            result.ColumnCount = 3;
            result.RowCount = 3;

            mat_A.ColumnCount = 3;
            mat_A.RowCount = 3;

            mat_B.ColumnCount = 3;
            mat_B.RowCount = 3;
        }

        public void SetDataGridViewData(DataGridView dgv, object[,] data)
        {
            // Determine the number of rows and columns in the DataGridView
            int numRows = dgv.Rows.Count;
            int numCols = dgv.Columns.Count;

            // Loop through each row and column to set the cell data
            for (int i = 0; i < numRows; i++)
            {
                for (int j = 0; j < numCols; j++)
                {
                    dgv.Rows[i].Cells[j].Value = data[i, j];
                }
            }
        }

        private void ClearAllCells(DataGridView dgv)
        {
            // Clear all cells in mat_A
            for (int i = 0; i < dgv.Rows.Count; i++)
            {
                for (int j = 0; j < dgv.Columns.Count; j++)
                {
                    dgv.Rows[i].Cells[j].Value = "";
                }
            }
        }



        public void matrixSumming(DataGridView f1, DataGridView f2, DataGridView t)
                {
                    // Sum the matrices and store the result in mat_C
                    for (int i = 0; i < f1.Rows.Count; i++)
                    {
                        for (int j = 0; j < f1.Columns.Count; j++)
                        {
                            int val_A = Convert.ToInt32(f1.Rows[i].Cells[j].Value);
                            int val_B = Convert.ToInt32(f2.Rows[i].Cells[j].Value);
                            int val_C = val_A + val_B;
                            t.Rows[i].Cells[j].Value = val_C;
                        }
                    }


                }

        public void matrixMultiply(DataGridView f1, DataGridView f2, DataGridView t)
        {
            // Sum the matrices and store the result in mat_C
            for (int i = 0; i < f1.Rows.Count; i++)
            {
                for (int j = 0; j < f1.Columns.Count; j++)
                {
                    int val_A = Convert.ToInt32(f1.Rows[i].Cells[j].Value);
                    int val_B = Convert.ToInt32(f2.Rows[i].Cells[j].Value);
                    int val_C = val_A * val_B;
                    t.Rows[i].Cells[j].Value = val_C;
                }
            }


        }

        public void matrixSub(DataGridView f1, DataGridView f2, DataGridView t)
        {
            // Sum the matrices and store the result in mat_C
            for (int i = 0; i < f1.Rows.Count; i++)
            {
                for (int j = 0; j < f1.Columns.Count; j++)
                {
                    int val_A = Convert.ToInt32(f1.Rows[i].Cells[j].Value);
                    int val_B = Convert.ToInt32(f2.Rows[i].Cells[j].Value);
                    int val_C = val_A - val_B;
                    t.Rows[i].Cells[j].Value = val_C;
                }
            }


        }

        public void InvertMatrix(DataGridView dgv)
        {
            // Get the data from the DataGridView
            object[,] data = GetDataGridViewData(dgv);

            // Check that the matrix is square
            int numRows = dgv.Rows.Count;
            int numCols = dgv.Columns.Count;
            if (numRows != numCols)
            {
                throw new Exception("Matrix must be square.");
            }

            // Create a copy of the original matrix to work with
            double[,] matrix = new double[numRows, numCols];
            for (int i = 0; i < numRows; i++)
            {
                for (int j = 0; j < numCols; j++)
                {
                    matrix[i, j] = Convert.ToDouble(data[i, j]);
                }
            }

            // Initialize the inverse matrix as the identity matrix
            double[,] inverse = new double[numRows, numCols];
            for (int i = 0; i < numRows; i++)
            {
                for (int j = 0; j < numCols; j++)
                {
                    if (i == j)
                    {
                        inverse[i, j] = 1.0;
                    }
                    else
                    {
                        inverse[i, j] = 0.0;
                    }
                }
            }

            // Perform Gaussian elimination on the matrix and its inverse
            for (int k = 0; k < numRows; k++)
            {
                double pivot = matrix[k, k];
                if (pivot == 0.0)
                {
                    throw new Exception("Matrix is singular.");
                }

                for (int j = 0; j < numCols; j++)
                {
                    matrix[k, j] /= pivot;
                    inverse[k, j] /= pivot;
                }

                for (int i = 0; i < numRows; i++)
                {
                    if (i == k)
                    {
                        continue;
                    }

                    double factor = matrix[i, k];
                    for (int j = 0; j < numCols; j++)
                    {
                        matrix[i, j] -= factor * matrix[k, j];
                        inverse[i, j] -= factor * inverse[k, j];
                    }
                }
            }

            // Set the inverted values back to the DataGridView
            for (int i = 0; i < numRows; i++)
            {
                for (int j = 0; j < numCols; j++)
                {
                    dgv.Rows[i].Cells[j].Value = inverse[i, j];
                }
            }
        }





        public object[,] GetDataGridViewData(DataGridView dgv)
        {
            // Determine the number of rows and columns in the DataGridView
            int numRows = dgv.Rows.Count;
            int numCols = dgv.Columns.Count;

            // Create a 2D array to hold the cell data
            object[,] data = new object[numRows, numCols];

            // Loop through each row and column to retrieve the cell data
            for (int i = 0; i < numRows; i++)
            {
                for (int j = 0; j < numCols; j++)
                {
                    data[i, j] = dgv.Rows[i].Cells[j].Value;
                }
            }

            // Return the cell data as a 2D array
            return data;
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
            matrixSumming(mat_A, mat_B, result);

        }

        private void button3_Click(object sender, EventArgs e)
        {
            //trasfer grid data from mat_A to mat_B
            
            SetDataGridViewData(mat_B, GetDataGridViewData(mat_A));
            ClearAllCells(mat_A);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            //trasfer grid data from mat_B to mat_A
            
            SetDataGridViewData(mat_A, GetDataGridViewData(mat_B));
            ClearAllCells(mat_B);
        }

        private void button14_Click(object sender, EventArgs e)
        {
            //trasfer grid data from result to mat_B
            
            SetDataGridViewData(mat_B, GetDataGridViewData(result));
            ClearAllCells(result);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            matrixMultiply(mat_A, mat_B, result);
        }

        private void button7_Click(object sender, EventArgs e)
        {
            matrixSub(mat_A, mat_B, result);
        }

        private void button9_Click(object sender, EventArgs e)
        {
            InvertMatrix(mat_A);
        }
    }
}